import routes from "./routes/routes.js";
import UrlParser from "./utils/url-parser.js";

const viewEl = document.getElementById("view");

async function renderRoute() {
  const parsed = UrlParser.parseActiveUrlWithCombiner();

  // Routing logic
  let page = routes[parsed];
  if (!page) {
    page = routes["/404"];
  }

  // ============
  // LOGIK NAVBAR
  // ============
  const navbar = document.querySelector(".navbar");
  const hideNavRoutes = ["/", "/login", "/register"];

  if (hideNavRoutes.includes(parsed)) {
    if (navbar) navbar.style.display = "none";
  } else {
    if (navbar) navbar.style.display = "block";
  }

  const doRender = async () => {
    viewEl.innerHTML = await page.render();

    if (page.afterRender) {
      await page.afterRender();
    }

    // Fokus aksesibilitas ke konten utama
    const main = document.querySelector("#main-content");
    if (main) {
      if (!main.hasAttribute("tabindex")) main.setAttribute("tabindex", "-1");
      main.focus();
    }
  };

  // === PERBAIKAN ERROR VIEW TRANSITION ===
  if (document.startViewTransition) {
    const transition = document.startViewTransition(doRender);
    // Tangkap error abort agar tidak muncul "Uncaught runtime error"
    transition.finished.catch(() => {});
  } else {
    await doRender();
  }
}

/** ==========================
 * INIT APP
 * ==========================*/
function init() {
  const bindLogout = () => {
    const logoutBtn = document.getElementById("logoutBtn");
    if (logoutBtn) {
      logoutBtn.onclick = () => {
        localStorage.removeItem("token");
        localStorage.removeItem("name");
        window.location.hash = "#/login";
      };
    }
  };

  // Render saat load
  renderRoute().then(bindLogout);

  // Render saat hash berubah
  window.addEventListener("hashchange", () => {
    renderRoute().then(bindLogout);
  });
}

window.addEventListener("load", init);

export default renderRoute;
