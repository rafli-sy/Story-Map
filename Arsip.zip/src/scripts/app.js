// src/scripts/app.js
import routes from "./routes/routes.js";
import UrlParser from "./utils/url-parser.js";

const viewEl = document.getElementById("view");

/**
 * Render halaman berdasarkan hash URL
 */
async function renderRoute() {
  const parsed = UrlParser.parseActiveUrlWithCombiner();
  const page = routes[parsed] || routes["/404"];

  // Transition keluar
  viewEl.style.opacity = 0;
  viewEl.style.transform = "translateY(6px)";
  await new Promise((r) => setTimeout(r, 120));

  // Render halaman
  viewEl.innerHTML = await page.render();

  // Setelah halaman masuk ke DOM
  if (page.afterRender) {
    await page.afterRender();
  }

  // Transition masuk
  await new Promise((r) => setTimeout(r, 10));
  viewEl.style.opacity = 1;
  viewEl.style.transform = "none";

  // Fokus ke <main> untuk aksesibilitas
  const main = document.querySelector("main");
  if (main) main.focus();
}

/**
 * Setup awal saat browser load
 */
window.addEventListener("load", () => {
  // tombol logout
  const logoutBtn = document.getElementById("logoutBtn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      localStorage.removeItem("token");
      localStorage.removeItem("name");
      window.location.hash = "#/";
    });
  }

  renderRoute();
});

// Routing saat hash berubah
window.addEventListener("hashchange", renderRoute);

export default renderRoute;
