import Api from "../data/api.js";
import { createStoryCard, showLoading } from "../utils/index.js";
import StoryIdb from "../data/story-db.js";
import NotificationHelper from "../utils/notification.js";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

const Home = {
  render: async () => {
    const name = localStorage.getItem("name") || "User";

    return `
      <main role="main" id="main-content">
        <section class="home" aria-labelledby="home-title">
          <div class="greeting" style="display:flex; justify-content:space-between; align-items:center;">
            <div>
              <h1 id="home-title">Hello, ${name} 👋</h1>
              <p class="muted">Welcome back!</p>
            </div>
            
            <button id="notifBtn" class="btn-pill" style="font-size:0.85rem; padding:8px 16px; display:flex; align-items:center; gap:6px;">
              🔔 Aktifkan Notifikasi
            </button>
          </div>

          <div class="map-section" aria-label="Peta cerita">
            <div class="map-title">Peta</div>
            <div id="map" class="map-container" style="height:350px; border-radius:12px; overflow:hidden;">
              <div id="map-placeholder" class="center">Memuat peta...</div>
            </div>
          </div>

          <section aria-labelledby="stories-title">
            <h2 id="stories-title" class="section-title">Story</h2>
            <div id="offlineMessage"></div>
            <div id="storyGrid" class="story-grid" role="list" aria-live="polite"></div>

            <div class="add-story-wrap">
              <button id="gotoAdd" class="btn-pill" aria-label="Tambah story baru">+ Add Story</button>
            </div>
          </section>
        </section>
      </main>
    `;
  },

  afterRender: async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      window.location.hash = "#/";
      return;
    }

    // --- 1. LOGIK SUBSCRIBE NOTIFIKASI (DIPERBAIKI) ---
    const notifBtn = document.getElementById("notifBtn");
    if (!("Notification" in window)) {
      if (notifBtn) notifBtn.style.display = "none";
    } else {
      if (notifBtn) {
        notifBtn.addEventListener("click", async () => {
          try {
            const subscription =
              await NotificationHelper.subscribePushNotification();
            if (subscription) {
              const subscriptionJson = subscription.toJSON();
              // FIX: Gunakan method yang benar sesuai api.js
              await Api.subscribeToNotify(subscriptionJson);

              // Tampilkan notifikasi lokal sebagai tanda sukses
              showLocalNotification(
                "Notifikasi Aktif!",
                "Kamu sekarang akan menerima update terbaru."
              );
            } else {
              alert("Izin notifikasi ditolak.");
            }
          } catch (err) {
            console.error("Error subscription:", err);
            alert("Gagal subscribe: " + err.message);
          }
        });
      }
    }

    // --- 2. INIT MAP ---
    const mapContainer = document.getElementById("map");
    if (mapContainer) {
      const placeholder = document.getElementById("map-placeholder");
      if (placeholder) placeholder.remove();

      const map = L.map("map").setView([-2.5, 118], 5);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: "&copy; OpenStreetMap contributors",
      }).addTo(map);

      // --- 3. LOAD STORIES ---
      const grid = document.getElementById("storyGrid");
      const offlineMsgContainer = document.getElementById("offlineMessage");

      if (grid) {
        showLoading(grid);
        try {
          const response = await Api.getStories(token, { location: 1 });
          const stories = response;

          await StoryIdb.clearStories();
          const savePromises = stories.map((story) => StoryIdb.putStory(story));
          await Promise.all(savePromises);

          await renderStoriesWithFavoriteLogic(stories, grid, map);
        } catch (err) {
          console.warn("Network fail, loading cache...", err);
          try {
            const cachedStories = await StoryIdb.getAllStories();
            if (cachedStories.length > 0) {
              offlineMsgContainer.innerHTML = `
                <div style="background-color: #fff3cd; color: #856404; padding: 12px; border-radius: 8px; margin-bottom: 16px;">
                  <strong>Mode Offline:</strong> Menampilkan data cache.
                </div>`;
              await renderStoriesWithFavoriteLogic(cachedStories, grid, map);
            } else {
              grid.innerHTML = `<p style="color:#b00;">Gagal memuat data.</p>`;
            }
          } catch (dbErr) {
            grid.innerHTML = `<p>Terjadi kesalahan.</p>`;
          }
        }
      }
    }

    const btnAdd = document.getElementById("gotoAdd");
    if (btnAdd) {
      btnAdd.addEventListener("click", () => {
        window.location.hash = "#/add";
      });
    }
  },
};

// --- HELPER: TAMPILKAN NOTIFIKASI LOKAL ---
function showLocalNotification(title, body) {
  if (Notification.permission === "granted") {
    navigator.serviceWorker.ready.then((registration) => {
      registration.showNotification(title, {
        body: body,
        icon: "./icons/icon-192.png",
        vibrate: [200, 100, 200],
      });
    });
  }
}

async function renderStoriesWithFavoriteLogic(
  stories,
  gridContainer,
  mapInstance
) {
  let favoriteIds = new Set();
  try {
    const favorites = await StoryIdb.getAllFavorites();
    favoriteIds = new Set(favorites.map((f) => f.id));
  } catch (e) {
    /* ignore */
  }

  gridContainer.innerHTML = stories.map((s) => createStoryCard(s)).join("");

  stories.forEach((s) => {
    if (s.lat && s.lon) {
      L.marker([s.lat, s.lon])
        .addTo(mapInstance)
        .bindPopup(`<strong>${s.name}</strong><br>${s.description || ""}`);
    }
  });

  setTimeout(() => mapInstance.invalidateSize(), 400);

  const cards = gridContainer.querySelectorAll(".story-card");
  cards.forEach((card) => {
    const id = card.dataset.id;
    const favBtn = card.querySelector(".btn-fav");

    if (favBtn) {
      if (favoriteIds.has(id)) {
        favBtn.textContent = "❤️";
      } else {
        favBtn.textContent = "🤍";
      }

      favBtn.addEventListener("click", async (e) => {
        e.stopPropagation();
        const storyData = stories.find((s) => s.id === id);

        if (favBtn.textContent === "🤍") {
          await StoryIdb.putFavorite(storyData);
          favBtn.textContent = "❤️";
          // --- TAMBAHAN: NOTIFIKASI SAAT FAVORITE ---
          showLocalNotification(
            "Story Disukai! ❤️",
            `Kamu menyukai cerita dari ${storyData.name}`
          );
        } else {
          await StoryIdb.deleteFavorite(id);
          favBtn.textContent = "🤍";
        }
      });
    }

    card.addEventListener("click", (e) => {
      if (e.target.classList.contains("btn-fav")) return;
      window.location.hash = `#/detail/${id}`;
    });
  });
}

export default Home;
