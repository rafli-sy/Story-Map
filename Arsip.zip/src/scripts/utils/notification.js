import CONFIG from "../config";

const NotificationHelper = {
  async subscribePushNotification() {
    if (!("serviceWorker" in navigator)) {
      console.log("Service Worker not supported in the browser");
      return null;
    }

    if (!("PushManager" in window)) {
      console.log("Push Manager not supported in the browser");
      return null;
    }

    try {
      const registration = await navigator.serviceWorker.ready;

      // Cek apakah user sudah subscribe
      let subscription = await registration.pushManager.getSubscription();
      if (subscription) {
        console.log("User is already subscribed.");
        return subscription;
      }

      // Minta izin notifikasi
      const permission = await Notification.requestPermission();
      if (permission !== "granted") {
        console.log("Notification permission denied");
        return null;
      }

      // ==================================================
      // PERBAIKAN: AMBIL VAPID KEY DARI API DICODING
      // ==================================================
      const response = await fetch(
        "https://story-api.dicoding.dev/v1/notifications/vapid-key"
      );
      const responseJson = await response.json();
      const vapidPublicKey = responseJson.data.publicKey;

      const applicationServerKey = this._urlBase64ToUint8Array(vapidPublicKey);

      subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: applicationServerKey,
      });

      console.log("User subscribed successfully with correct key.");
      return subscription;
    } catch (error) {
      console.error("Failed to subscribe to push notification", error);
      return null;
    }
  },

  _urlBase64ToUint8Array(base64String) {
    const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding)
      .replace(/-/g, "+")
      .replace(/_/g, "/");
    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);
    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  },
};

export default NotificationHelper;